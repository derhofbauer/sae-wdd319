<?php

namespace App\Controllers;

use App\Models\Product;
use Core\View;

class HomeController
{

    public function index ()
    {

        /**
         * [x] Alle Produkte aus Datenbank abfragen
         * [x] Produkte an View übergeben
         */

    }

}
